"use client"

import { useState, useEffect, useMemo } from "react"
import {
  Search,
  ShoppingCart,
  User,
  Plus,
  Edit,
  Trash2,
  Star,
  CreditCard,
  Package,
  Users,
  TrendingUp,
  Brain,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

// Types
interface IProduct {
  id: string
  name: string
  description: string
  price: number
  category: string
  image: string
  stock: number
  rating: number
  reviews: number
  tags: string[]
}

interface ICartItem {
  product: IProduct
  quantity: number
}

interface IOrder {
  id: string
  userId: string
  items: ICartItem[]
  total: number
  status: "pending" | "processing" | "shipped" | "delivered"
  createdAt: string
}

// Mock Data
const mockProducts: IProduct[] = [
  {
    id: "1",
    name: "Wireless Headphones",
    description: "Premium noise-cancelling wireless headphones with 30-hour battery life",
    price: 299.99,
    category: "Electronics",
    image: "/placeholder.svg?height=300&width=300",
    stock: 25,
    rating: 4.8,
    reviews: 124,
    tags: ["wireless", "audio", "premium"],
  },
  {
    id: "2",
    name: "Smart Watch",
    description: "Advanced fitness tracking smartwatch with heart rate monitor",
    price: 399.99,
    category: "Electronics",
    image: "/placeholder.svg?height=300&width=300",
    stock: 15,
    rating: 4.6,
    reviews: 89,
    tags: ["smartwatch", "fitness", "health"],
  },
  {
    id: "3",
    name: "Organic Cotton T-Shirt",
    description: "Comfortable organic cotton t-shirt in various colors",
    price: 29.99,
    category: "Clothing",
    image: "/placeholder.svg?height=300&width=300",
    stock: 50,
    rating: 4.4,
    reviews: 67,
    tags: ["organic", "cotton", "casual"],
  },
  {
    id: "4",
    name: "Coffee Maker",
    description: "Programmable drip coffee maker with thermal carafe",
    price: 149.99,
    category: "Home & Kitchen",
    image: "/placeholder.svg?height=300&width=300",
    stock: 12,
    rating: 4.7,
    reviews: 156,
    tags: ["coffee", "kitchen", "appliance"],
  },
  {
    id: "5",
    name: "Yoga Mat",
    description: "Non-slip eco-friendly yoga mat with carrying strap",
    price: 49.99,
    category: "Sports",
    image: "/placeholder.svg?height=300&width=300",
    stock: 30,
    rating: 4.5,
    reviews: 78,
    tags: ["yoga", "fitness", "eco-friendly"],
  },
  {
    id: "6",
    name: "Bluetooth Speaker",
    description: "Portable waterproof Bluetooth speaker with rich bass",
    price: 79.99,
    category: "Electronics",
    image: "/placeholder.svg?height=300&width=300",
    stock: 20,
    rating: 4.3,
    reviews: 92,
    tags: ["bluetooth", "speaker", "portable"],
  },
]

// AI Recommendation Engine (Simulated)
const getAIRecommendations = (user: any | null, cart: ICartItem[], viewedProducts: string[]): IProduct[] => {
  if (!user) return mockProducts.slice(0, 3)

  // Simple recommendation logic based on cart items and viewed products
  const userCategories = cart.map((item) => item.product.category)
  const viewedCategories = viewedProducts.map((id) => mockProducts.find((p) => p.id === id)?.category).filter(Boolean)
  const allCategories = [...userCategories, ...viewedCategories]

  const recommended = mockProducts.filter(
    (product) => allCategories.includes(product.category) && !cart.some((item) => item.product.id === product.id),
  )

  return recommended.slice(0, 4)
}

export default function ECommercePlatform() {
  // State Management
  const [user, setUser] = useState<any | null>(null)
  const [products, setProducts] = useState<IProduct[]>(mockProducts)
  const [cart, setCart] = useState<ICartItem[]>([])
  const [orders, setOrders] = useState<IOrder[]>([])
  const [viewedProducts, setViewedProducts] = useState<string[]>([])
  const [currentView, setCurrentView] = useState<"shop" | "cart" | "admin" | "profile">("shop")

  // Shop State
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1000])
  const [sortBy, setSortBy] = useState<"name" | "price" | "rating">("name")

  // Auth State
  const [showAuthDialog, setShowAuthDialog] = useState(false)
  const [authMode, setAuthMode] = useState<"login" | "register">("login")
  const [authForm, setAuthForm] = useState({ email: "", password: "", name: "" })

  // Admin State
  const [showProductDialog, setShowProductDialog] = useState(false)
  const [editingProduct, setEditingProduct] = useState<IProduct | null>(null)
  const [productForm, setProductForm] = useState({
    name: "",
    description: "",
    price: 0,
    category: "",
    stock: 0,
    image: "",
    tags: "",
  })

  // Checkout State
  const [showCheckout, setShowCheckout] = useState(false)
  const [paymentForm, setPaymentForm] = useState({
    cardNumber: "",
    expiryDate: "",
    cvv: "",
    name: "",
    address: "",
    city: "",
    zipCode: "",
  })

  // Authentication Functions
  const handleAuth = () => {
    if (authMode === "login") {
      // Simulate login
      const mockUser: any = {
        id: "1",
        email: authForm.email,
        name: authForm.name || "User",
        role: authForm.email === "admin@store.com" ? "admin" : "customer",
      }
      setUser(mockUser)
      localStorage.setItem("user", JSON.stringify(mockUser))
    } else {
      // Simulate registration
      const newUser: any = {
        id: Date.now().toString(),
        email: authForm.email,
        name: authForm.name,
        role: "customer",
      }
      setUser(newUser)
      localStorage.setItem("user", JSON.stringify(newUser))
    }
    setShowAuthDialog(false)
    setAuthForm({ email: "", password: "", name: "" })
  }

  const handleLogout = () => {
    setUser(null)
    setCart([])
    localStorage.removeItem("user")
    localStorage.removeItem("cart")
    setCurrentView("shop")
  }

  // Product Functions
  const addToCart = (product: IProduct) => {
    const existingItem = cart.find((item) => item.product.id === product.id)
    if (existingItem) {
      setCart(cart.map((item) => (item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)))
    } else {
      setCart([...cart, { product, quantity: 1 }])
    }

    // Track viewed products for AI recommendations
    if (!viewedProducts.includes(product.id)) {
      setViewedProducts([...viewedProducts, product.id])
    }
  }

  const removeFromCart = (productId: string) => {
    setCart(cart.filter((item) => item.product.id !== productId))
  }

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId)
    } else {
      setCart(cart.map((item) => (item.product.id === productId ? { ...item, quantity } : item)))
    }
  }

  // Admin Functions
  const handleProductSubmit = () => {
    if (editingProduct) {
      setProducts(
        products.map((p) =>
          p.id === editingProduct.id
            ? { ...editingProduct, ...productForm, tags: productForm.tags.split(",").map((t) => t.trim()) }
            : p,
        ),
      )
    } else {
      const newProduct: IProduct = {
        id: Date.now().toString(),
        ...productForm,
        rating: 0,
        reviews: 0,
        tags: productForm.tags.split(",").map((t) => t.trim()),
      }
      setProducts([...products, newProduct])
    }
    setShowProductDialog(false)
    setEditingProduct(null)
    setProductForm({ name: "", description: "", price: 0, category: "", stock: 0, image: "", tags: "" })
  }

  const deleteProduct = (productId: string) => {
    setProducts(products.filter((p) => p.id !== productId))
  }

  // Checkout Functions
  const handleCheckout = () => {
    const newOrder: IOrder = {
      id: Date.now().toString(),
      userId: user?.id || "",
      items: cart,
      total: cartTotal,
      status: "pending",
      createdAt: new Date().toISOString(),
    }
    setOrders([...orders, newOrder])
    setCart([])
    setShowCheckout(false)
    alert("Order placed successfully!")
  }

  // Computed Values
  const categories = ["all", ...Array.from(new Set(products.map((p) => p.category)))]

  const filteredProducts = useMemo(() => {
    return products
      .filter((product) => {
        const matchesSearch =
          product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          product.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))
        const matchesCategory = selectedCategory === "all" || product.category === selectedCategory
        const matchesPrice = product.price >= priceRange[0] && product.price <= priceRange[1]
        return matchesSearch && matchesCategory && matchesPrice
      })
      .sort((a, b) => {
        switch (sortBy) {
          case "price":
            return a.price - b.price
          case "rating":
            return b.rating - a.rating
          default:
            return a.name.localeCompare(b.name)
        }
      })
  }, [products, searchQuery, selectedCategory, priceRange, sortBy])

  const cartTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0)
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0)

  const aiRecommendations = getAIRecommendations(user, cart, viewedProducts)

  // Load user from localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem("user")
    if (savedUser) {
      setUser(JSON.parse(savedUser))
    }
    const savedCart = localStorage.getItem("cart")
    if (savedCart) {
      setCart(JSON.parse(savedCart))
    }
  }, [])

  // Save cart to localStorage
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart))
  }, [cart])

  // Components
  const ProductCard = ({ product }: { product: IProduct }) => (
    <Card className="group hover:shadow-lg transition-shadow">
      <CardContent className="p-4">
        <div className="aspect-square mb-4 overflow-hidden rounded-lg bg-gray-100">
          <img
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
          />
        </div>
        <div className="space-y-2">
          <div className="flex items-start justify-between">
            <h3 className="font-semibold text-sm line-clamp-2">{product.name}</h3>
            <Badge variant="secondary">{product.category}</Badge>
          </div>
          <p className="text-sm text-muted-foreground line-clamp-2">{product.description}</p>
          <div className="flex items-center gap-2">
            <div className="flex items-center">
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <span className="text-sm ml-1">{product.rating}</span>
            </div>
            <span className="text-sm text-muted-foreground">({product.reviews})</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-lg font-bold">${product.price}</span>
            <span className="text-sm text-muted-foreground">Stock: {product.stock}</span>
          </div>
          <Button onClick={() => addToCart(product)} className="w-full" disabled={product.stock === 0}>
            {product.stock === 0 ? "Out of Stock" : "Add to Cart"}
          </Button>
        </div>
      </CardContent>
    </Card>
  )

  const ShopView = () => (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="flex flex-col lg:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        <div className="flex gap-2">
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((category) => (
                <SelectItem key={category} value={category}>
                  {category === "all" ? "All Categories" : category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
            <SelectTrigger className="w-32">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name">Name</SelectItem>
              <SelectItem value="price">Price</SelectItem>
              <SelectItem value="rating">Rating</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* AI Recommendations */}
      {user && aiRecommendations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="w-5 h-5" />
              AI Recommendations for You
            </CardTitle>
            <CardDescription>Based on your browsing history and cart items</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {aiRecommendations.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No products found matching your criteria.</p>
        </div>
      )}
    </div>
  )

  const CartView = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Shopping Cart</h2>
        <Badge variant="secondary">{cartItemCount} items</Badge>
      </div>

      {cart.length === 0 ? (
        <div className="text-center py-12">
          <ShoppingCart className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground">Your cart is empty</p>
          <Button onClick={() => setCurrentView("shop")} className="mt-4">
            Continue Shopping
          </Button>
        </div>
      ) : (
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            {cart.map((item) => (
              <Card key={item.product.id}>
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <img
                      src={item.product.image || "/placeholder.svg"}
                      alt={item.product.name}
                      className="w-20 h-20 object-cover rounded"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold">{item.product.name}</h3>
                      <p className="text-sm text-muted-foreground">{item.product.description}</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="font-bold">${item.product.price}</span>
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                          >
                            -
                          </Button>
                          <span className="w-8 text-center">{item.quantity}</span>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                          >
                            +
                          </Button>
                          <Button size="sm" variant="destructive" onClick={() => removeFromCart(item.product.id)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="h-fit">
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                {cart.map((item) => (
                  <div key={item.product.id} className="flex justify-between text-sm">
                    <span>
                      {item.product.name} x{item.quantity}
                    </span>
                    <span>${(item.product.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>
              <Separator />
              <div className="flex justify-between font-bold">
                <span>Total</span>
                <span>${cartTotal.toFixed(2)}</span>
              </div>
              <Button className="w-full" onClick={() => setShowCheckout(true)} disabled={!user}>
                {user ? "Proceed to Checkout" : "Login to Checkout"}
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )

  const AdminView = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Admin Dashboard</h2>
        <Button onClick={() => setShowProductDialog(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Product
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Package className="w-8 h-8 text-blue-500" />
              <div>
                <p className="text-sm text-muted-foreground">Total Products</p>
                <p className="text-2xl font-bold">{products.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <ShoppingCart className="w-8 h-8 text-green-500" />
              <div>
                <p className="text-sm text-muted-foreground">Total Orders</p>
                <p className="text-2xl font-bold">{orders.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="w-8 h-8 text-purple-500" />
              <div>
                <p className="text-sm text-muted-foreground">Active Users</p>
                <p className="text-2xl font-bold">1</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-8 h-8 text-orange-500" />
              <div>
                <p className="text-sm text-muted-foreground">Revenue</p>
                <p className="text-2xl font-bold">${orders.reduce((sum, order) => sum + order.total, 0).toFixed(2)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Products Table */}
      <Card>
        <CardHeader>
          <CardTitle>Product Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {products.map((product) => (
              <div key={product.id} className="flex items-center gap-4 p-4 border rounded-lg">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-16 h-16 object-cover rounded"
                />
                <div className="flex-1">
                  <h3 className="font-semibold">{product.name}</h3>
                  <p className="text-sm text-muted-foreground">{product.category}</p>
                  <p className="font-bold">${product.price}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm">Stock: {product.stock}</p>
                  <p className="text-sm">Rating: {product.rating}</p>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setEditingProduct(product)
                      setProductForm({
                        name: product.name,
                        description: product.description,
                        price: product.price,
                        category: product.category,
                        stock: product.stock,
                        image: product.image,
                        tags: product.tags.join(", "),
                      })
                      setShowProductDialog(true)
                    }}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => deleteProduct(product.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl font-bold">E-Store</h1>
              <nav className="hidden md:flex gap-4">
                <Button variant={currentView === "shop" ? "default" : "ghost"} onClick={() => setCurrentView("shop")}>
                  Shop
                </Button>
                {user?.role === "admin" && (
                  <Button
                    variant={currentView === "admin" ? "default" : "ghost"}
                    onClick={() => setCurrentView("admin")}
                  >
                    Admin
                  </Button>
                )}
              </nav>
            </div>

            <div className="flex items-center gap-4">
              <Button variant="outline" size="sm" onClick={() => setCurrentView("cart")} className="relative">
                <ShoppingCart className="w-4 h-4" />
                {cartItemCount > 0 && (
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                    {cartItemCount}
                  </Badge>
                )}
              </Button>

              {user ? (
                <div className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user.avatar || "/placeholder.svg"} />
                    <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <span className="hidden md:inline text-sm">{user.name}</span>
                  <Button variant="outline" size="sm" onClick={handleLogout}>
                    Logout
                  </Button>
                </div>
              ) : (
                <Button onClick={() => setShowAuthDialog(true)}>
                  <User className="w-4 h-4 mr-2" />
                  Login
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {currentView === "shop" && <ShopView />}
        {currentView === "cart" && <CartView />}
        {currentView === "admin" && user?.role === "admin" && <AdminView />}
      </main>

      {/* Auth Dialog */}
      <Dialog open={showAuthDialog} onOpenChange={setShowAuthDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{authMode === "login" ? "Login" : "Register"}</DialogTitle>
            <DialogDescription>
              {authMode === "login"
                ? "Enter your credentials to access your account"
                : "Create a new account to start shopping"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {authMode === "register" && (
              <div>
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={authForm.name}
                  onChange={(e) => setAuthForm({ ...authForm, name: e.target.value })}
                />
              </div>
            )}
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={authForm.email}
                onChange={(e) => setAuthForm({ ...authForm, email: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={authForm.password}
                onChange={(e) => setAuthForm({ ...authForm, password: e.target.value })}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleAuth} className="flex-1">
                {authMode === "login" ? "Login" : "Register"}
              </Button>
              <Button variant="outline" onClick={() => setAuthMode(authMode === "login" ? "register" : "login")}>
                {authMode === "login" ? "Register" : "Login"}
              </Button>
            </div>
            <p className="text-sm text-muted-foreground text-center">Demo: Use admin@store.com for admin access</p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Product Dialog */}
      <Dialog open={showProductDialog} onOpenChange={setShowProductDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingProduct ? "Edit Product" : "Add Product"}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="product-name">Name</Label>
              <Input
                id="product-name"
                value={productForm.name}
                onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="product-category">Category</Label>
              <Input
                id="product-category"
                value={productForm.category}
                onChange={(e) => setProductForm({ ...productForm, category: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="product-price">Price</Label>
              <Input
                id="product-price"
                type="number"
                value={productForm.price}
                onChange={(e) => setProductForm({ ...productForm, price: Number.parseFloat(e.target.value) })}
              />
            </div>
            <div>
              <Label htmlFor="product-stock">Stock</Label>
              <Input
                id="product-stock"
                type="number"
                value={productForm.stock}
                onChange={(e) => setProductForm({ ...productForm, stock: Number.parseInt(e.target.value) })}
              />
            </div>
            <div className="col-span-2">
              <Label htmlFor="product-description">Description</Label>
              <Textarea
                id="product-description"
                value={productForm.description}
                onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
              />
            </div>
            <div className="col-span-2">
              <Label htmlFor="product-image">Image URL</Label>
              <Input
                id="product-image"
                value={productForm.image}
                onChange={(e) => setProductForm({ ...productForm, image: e.target.value })}
              />
            </div>
            <div className="col-span-2">
              <Label htmlFor="product-tags">Tags (comma separated)</Label>
              <Input
                id="product-tags"
                value={productForm.tags}
                onChange={(e) => setProductForm({ ...productForm, tags: e.target.value })}
              />
            </div>
          </div>
          <div className="flex gap-2">
            <Button onClick={handleProductSubmit} className="flex-1">
              {editingProduct ? "Update Product" : "Add Product"}
            </Button>
            <Button variant="outline" onClick={() => setShowProductDialog(false)}>
              Cancel
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Checkout Dialog */}
      <Dialog open={showCheckout} onOpenChange={setShowCheckout}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Checkout</DialogTitle>
            <DialogDescription>Complete your purchase</DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold mb-4">Order Summary</h3>
              <div className="space-y-2">
                {cart.map((item) => (
                  <div key={item.product.id} className="flex justify-between text-sm">
                    <span>
                      {item.product.name} x{item.quantity}
                    </span>
                    <span>${(item.product.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
                <Separator />
                <div className="flex justify-between font-bold">
                  <span>Total</span>
                  <span>${cartTotal.toFixed(2)}</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Payment Information</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label htmlFor="card-name">Cardholder Name</Label>
                  <Input
                    id="card-name"
                    value={paymentForm.name}
                    onChange={(e) => setPaymentForm({ ...paymentForm, name: e.target.value })}
                  />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="card-number">Card Number</Label>
                  <Input
                    id="card-number"
                    placeholder="1234 5678 9012 3456"
                    value={paymentForm.cardNumber}
                    onChange={(e) => setPaymentForm({ ...paymentForm, cardNumber: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="expiry">Expiry Date</Label>
                  <Input
                    id="expiry"
                    placeholder="MM/YY"
                    value={paymentForm.expiryDate}
                    onChange={(e) => setPaymentForm({ ...paymentForm, expiryDate: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="cvv">CVV</Label>
                  <Input
                    id="cvv"
                    placeholder="123"
                    value={paymentForm.cvv}
                    onChange={(e) => setPaymentForm({ ...paymentForm, cvv: e.target.value })}
                  />
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Shipping Address</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label htmlFor="address">Address</Label>
                  <Input
                    id="address"
                    value={paymentForm.address}
                    onChange={(e) => setPaymentForm({ ...paymentForm, address: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="city">City</Label>
                  <Input
                    id="city"
                    value={paymentForm.city}
                    onChange={(e) => setPaymentForm({ ...paymentForm, city: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="zip">ZIP Code</Label>
                  <Input
                    id="zip"
                    value={paymentForm.zipCode}
                    onChange={(e) => setPaymentForm({ ...paymentForm, zipCode: e.target.value })}
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleCheckout} className="flex-1">
                <CreditCard className="w-4 h-4 mr-2" />
                Place Order
              </Button>
              <Button variant="outline" onClick={() => setShowCheckout(false)}>
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
